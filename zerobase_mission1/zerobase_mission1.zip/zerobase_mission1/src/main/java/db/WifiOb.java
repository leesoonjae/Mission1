package db;

import java.util.*;
import java.io.InputStreamReader;

public class WifiOb {
}
